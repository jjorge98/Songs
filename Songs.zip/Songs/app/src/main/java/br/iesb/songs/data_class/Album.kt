package br.iesb.songs.data_class

data class Album(
    val id: Int,
    val title: String,
    val cover: String,
    val tracklist: String
)